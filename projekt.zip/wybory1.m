wybor = menu('Wybierz V', 'V=4', 'V=8', 'V=12', "Dowolna wartosc",'P(t)','M(omega)', 'wyjście')

global V kol p;

switch wybor
    case 1
        V=4;
        kol='g';
        projekt2_1;
        wybory1;

    case 2
        V=8;
        kol='b';
        projekt2_1;
        wybory1;

    case 3
        V=12;
        kol='r';
        projekt2_1;
        wybory1;

    case 4
        V = input("Podaj wartosc V: ");
        kol='m';
        projekt2_1;
        wybory1;
    case 5
        wybory4;
        wybory1;
     case 6
         wybor = menu('Wybierz V', 'V=4', 'V=8', 'V=12', "Dowolna wartosc", 'wyjście')

        switch wybor
        case 1
        V=4;
        kol='g';
        p = 1;
        wybory5;

        case 2
        V=8;
        kol='b';
        p = 1;
        wybory5;

        case 3
        V=12;
        kol='r';
        p = 1;
        wybory5;
        case 4
        V = input("Podaj wartosc V: ");
        kol='m';
        p = 1;
        wybory5;
        case 5
        clc;
        clear;
        close all;

        end
   

    case 7
        clc;
        clear;
        close all;

end