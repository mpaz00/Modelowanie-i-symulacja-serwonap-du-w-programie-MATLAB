wybor = menu('Wybierz Rs', 'Rs=0.3', 'Rs=1', 'Rs=3.5',"Dowolna wartosc", 'wyjście')

global Rs;

switch wybor
    case 1
        Rs=0.3;
        kol='g';
        projekt2_3;
        wybory3;

    case 2
        Rs=1;
        kol='b';
        projekt2_3;
        wybory3;

    case 3
        Rs=3.5;
        kol='r';
        projekt2_3;
        wybory3;
    case 4
        Rs = input("Podaj wartosc Rs: ");
        kol='m';
        projekt2_3;
        wybory3;
    case 5
        clc;
        clear;
        close all;

end