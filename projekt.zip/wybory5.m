wybor = menu('Wybierz Tz', 'Tz=0', 'Tz=0.05', 'Tz=0.1','Dowolna wartosc', 'wyjście')

global Tz;

switch wybor
    case 1
        Tz=0;
        kol='g';
        projekt2_5;
        wybory5;

    case 2
        Tz=0.05;
        kol='b';
        projekt2_5;
        wybory5;

    case 3
        Tz=0.1;
        kol='r';
        projekt2_5;
        wybory5;
    case 4
        Tz = input("Podaj wartosc Tz: ");
        kol='m';
        projekt2_5;
        wybory5

    case 5
        clc;
        clear;
        close all;

end