wybor = menu('Wybierz J', 'J=0.001', 'J=0.005', 'J=0.015',"Dowolna wartosc", 'wyjście')

global J;

switch wybor
    case 1
        J=0.001;
        kol='g';
        projekt2_2;
        wybory2;

    case 2
        J=0.005;
        kol='b';
        projekt2_2;
        wybory2;

    case 3
        J=0.015;
        kol='r';
        projekt2_2;
        wybory2;
    case 4
        J = input("Podaj wartosc J: ");
        kol='m';
        projekt2_2;
        wybory2;
    case 5
        clc;
        clear;
        close all;

end