wybor = menu('Wybierz V', 'V=4', 'V=8', 'V=12', "Dowolna wartosc", 'wyjście')

global V;

switch wybor
    case 1
        V=4;
        kol='g';
        projekt2_4;
        wybory4;

    case 2
        V=8;
        kol='b';
        projekt2_4;
        wybory4;

    case 3
        V=12;
        kol='r';
        projekt2_4;
        wybory4;
    case 4
        V = input("Podaj wartosc V: ");
        kol='m';
        projekt2_4;
        wybory4;
    case 5
        clc;
        clear;
        close all;

end