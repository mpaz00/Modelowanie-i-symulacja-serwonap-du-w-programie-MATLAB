% modelowanie silnika DC 
clc;
clear;

%kol='b'; % kolor na wykresach (b, k, r, c, m, g, y)
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% dane wejściowe

%%%Ustal zmienne globalne
global Rs L J Bt Tz ke km Om_0 ts V kol p t pom;

Rs=1; %[Om] oporność cewki wirnika
L=0.01;  %[H] indukcyjność cewki
J=0.001; %[kg/m2] moment bezwładności wirnika silnika
Bt=0.002; %[Nm*s] wsp. oporu obrotu wirnika

ke=0.1; %stała elektromotoryczna silnika
km=0.1; %stała momentu silnika
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Om_0=0*pi/30; %początkowa prędkość silnika [rad/s]
ts=0.7; %[s] czas symulacji





t=[0:0.01:ts];
war_pocz=[0 Om_0 0]';
dx=dc_model1(0,war_pocz);
[Ts,Xs]=ode45('dc_model1',t,war_pocz);

Fi=Xs(:,1);
Om=Xs(:,2);
Iw=Xs(:,3);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Wykresy

%prędkosc obroty i kąt
figure(1)

if p == 1
    reg_x = [0 0 0];
    reg_y = [0 0 0];
end

reg_x(p) = max(Om);
reg_y(p) = Tz;


hold on
plot(max(Om),Tz,append(kol,'*'),'MarkerSize', 12)
xlabel('omega [rad/s]')
title('Wykres M[omega]')
ylabel('M [Nm]')
grid on


if p == 3
    pom = polyfit(reg_x,reg_y,1);
    plot([0 (-pom(2)/pom(1))],[pom(2) 0],kol)
    text(((-pom(2)/pom(1))/2),pom(2)/2+0.015,append('V=',num2str(V)),'Color',kol)
end

p = p + 1;


