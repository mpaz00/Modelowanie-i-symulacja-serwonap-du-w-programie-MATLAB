clear all                               
close all                               
clc
disp('Projekt 2')                      
disp('Wykonały: Mariola Paź, Karolina Niziołek')  


wybor = menu('Wybierz Zadanie', 'Zmiana V', 'Zmiana J', 'Zmiana Rs', 'wyjście')

switch wybor
    case 1
        wybory1;
        PROJEKT_2_START;

    case 2
        wybory2;
        PROJEKT_2_START;

    case 3
        wybory3;
        PROJEKT_2_START;

    case 4
        clc;
        clear;
        close all;

end