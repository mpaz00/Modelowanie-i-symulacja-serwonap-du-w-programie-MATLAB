
global Rs L Bt Tz ke km Om_0 ts V kol;

Rs=1; %[Om] oporność cewki wirnika
L=0.01;  %[H] indukcyjność cewki
%J=0.001; %[kg/m2] moment bezwładności wirnika silnika
Bt=0.002; %[Nm*s] wsp. oporu obrotu wirnika
Tz=0; %[Nm] stały moment obciążenia zewnętrznego
ke=0.1; %stała elektromotoryczna silnika
km=0.1; %stała momentu silnika
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Om_0=0*pi/30; %początkowa prędkość silnika [rad/s]
ts=0.7; %[s] czas symulacji
V=12; %[V] napięcie zasilania
% program 1- rozpędzanie silnika bez obciążenia zewn.
% V= 4, 8, 12;
% program 2- rozpędzanie   silnika bez obciążenia zewn.
% V= 12;
% wpływ zmiany J (moment bezwładności wirnika)
% program 3- rozpędzanie silnika bez obciążenia zewn.
% V= 12;
% wpływ zmiany Rs (oporności el. wirnika)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%rozwiązanie układu równań
t=[0:0.01:ts];
war_pocz=[0 Om_0 0]';
dx=dc_model1(0,war_pocz);
[Ts,Xs]=ode45('dc_model1',t,war_pocz);
Fi=Xs(:,1);
Om=Xs(:,2);
Iw=Xs(:,3);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Wykresy
 %prędkość obrotu i kąt

figure(1)
subplot(3,1,1)
hold on     %%%zamrożenie rys
plot(Ts,Om*30/pi,kol)
xlabel('t [s]')
ylabel(' predkosc obr. [obr/min]')
grid on

subplot(3,1,2) 
hold on     %%%zamrożenie rys
plot(Ts,Fi*180/pi,kol)
xlabel('t [s]')
ylabel('kat obrotu [deg]')
grid on

subplot(3,1,3) 
hold on     %%%zamrożenie rys
plot(Ts,Iw,kol)
xlabel('t [s]')
ylabel('I [A]')
grid on
